# BPS Gellért Sötét Mód & Témagaléria (Firefox Bővítmény)

Egyedi sötét téma és gazdag témagaléria a **Budapest School Gellért** Base44 webes alkalmazásához (`https://bps-gell-rt.base44.app/*`, `student-dashboard`, `osztalyterem`, stb.).

---

## 🚀 Telepítés & Újratöltés Firefoxban

1. Nyisd meg a Firefoxban a következőt a címsorba írva:  
   `about:debugging#/runtime/this-firefox`
2. Kattints az **Ideiglenes kiegészítő betöltése...** (Load Temporary Add-on...) gombra.
3. Válaszd ki a projekt mappájából a [`manifest.json`](manifest.json) fájlt.
4. Ha módosítasz a kódon, elég a kiegészítő mellett az **Újratöltés (Reload)** gombra kattintani, majd frissíteni a Base44 weboldalt (`F5` vagy `Ctrl+R`).

---

## ✨ Főbb Funkciók

- **🎨 20+ Prémium Téma & Színkombináció:**
  - *Digital Horizon*, *Blossom*, *Bubblegum*, *Cherry*, *Coral*, *Express*, *Hyper*, *May*, *Pastel*
  - *Slate Indigo*, *Midnight OLED (Fekete & Neon)*, *Tokyo Night*, *Cyberpunk Neon*, *Emerald Matrix*, *Gellért Gold (natív Base44 sötét mód)*, *Nord Frost*, *Dracula*, *Forest Moss*, *Ocean Abyss*, *Sunset Vibes*.
- **🔍 Interaktív Színszűrő (Filter Bar):**
  - 10 színkapszula (Piros, Narancs, Sárga, Zöld, Sötétzöld, Ciánkék, Kék, Lila, Rózsaszín, Sötét).
  - Egy kattintással szűrhetsz a színek szerint, ismételt kattintással visszaállíthatod a teljes listát.
- **⚙️ Discord-szerű Beállítások:**
  - Közvetlenül a harang és felkiáltójel ikonok mellé beépített fogaskerék ikon.
  - Külön kategóriák a megjelenéshez, témákhoz, kártyákhoz, oldalsávhoz, animációkhoz és haladó beállításokhoz.
  - Sima oldalváltás, teljesítmény mód és nem érzékeny technikai debug állapotok.
- **✨ Animációs stílusok:**
  - Az Animációk fülön választható a *Finom*, *Erős*, *Neon*, *Bounce* vagy *Minimal* ikonanimáció.
  - A választott stílus az oldalsáv hover- és kattintási animációira vonatkozik, és elmentődik.
- **⚡ Azonnali Reakció & Nulla Fehér Villanás:**
  - A téma és háttérszínek `hsl(var(--card))` és `hsl(var(--background))` tokenekkel azonnal, újratöltés nélkül alkalmazkodnak.
  - `document_start` betöltés.
- **⌨️ Gyorsbillentyű:**
  - `Alt + Shift + D` gyorsbillentyű a sötét/világos mód váltásához.
- **🃏 Pranker fül:**
  - A beállítások panelen külön fülön átírhatod a műszerfalon látható *Felkiáltó*, *Mínusz* és *Plusz* darabszámokat.
  - Ezek csak helyi, vizuális próbaértékek; a Base44 valódi adatait nem módosítják.
  - A *Valódi weboldalas értékek visszaállítása* gomb kikapcsolja az átírást és visszaállítja az aktuális oldalon látható eredeti számokat.
- **⚙️ Advanced fül:**
  - A Témák, Animációk és Pranker fülek külön-külön elrejthetők.
  - Az Advanced fül mindig látható marad, hogy a beállítások később visszakapcsolhatók legyenek.
